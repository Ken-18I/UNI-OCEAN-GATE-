#Programa que usa OpenGL y Mediapipe para desarrollar un juego donde el objeto sigue el movimiento del rostro
# Referencia: https://www.youtube.com/watch?v=_BjL6W71mWY&t=452s
from game import Game

# Crear una instancia de la clase Game y llamar al método loop()
Game().loop()