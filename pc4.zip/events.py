import pygame

ADD_ENEMY = pygame.USEREVENT + 1